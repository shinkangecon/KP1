function f=mod_calibrationd(x,stock,gold,monshock,estar,c_1f,c_1r,c_2r,c_2f,c_4m,c_5y1,c_5y2,c_5y3,c_5y,b_c)
    






end